import { useEffect } from "react";
import { useDispatch } from "react-redux";
import { useAppSelector, type AppDispatch } from "../../redux/store/store";
import { fetchUserProfile } from "../../redux/actions/profileAction";

const useAuth = () => {
  const dispatch = useDispatch<AppDispatch>();
  const { userProfileData, userProfileIsloading, userProfileIserror } =
    useAppSelector((store) => store.profile.userProfile);

  useEffect(() => {
    if (!userProfileData) {
      dispatch(fetchUserProfile());
    }
  }, [dispatch, userProfileData]);

  return {
    isAuthenticated: Boolean(userProfileData),
    isLoading: userProfileIsloading,
    hasLoaded: !userProfileIsloading,
    user: userProfileData,
    error: userProfileIserror,
  };
};

export default useAuth;
